@extends('layouts.app2')

@section("content")
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h3>Subject</h3>
              <div class="panel panel-default">
              	<table style="width:100%" border="1">
				  <tr>
				    <th>Subject Name</th>
				    <th>Days & Time</th> 
				    <th>Teacher</th>
				  </tr>
				  <tr>
				  <td>ITPHP2</td>
				  <td>MWF - 6:31 - 8:31 </td> 
				  <td>Mr. Gian Carlo Cataraja</td>
				  </tr>
				  <tr>
				    <td>CIS</td>
				    <td>TTH - 10:30 - 12:00</td>
				    <td>Mr. Bell Campanilla</td>
				  </tr>
				  <tr>
				    <td>Practicum 42</td>
				    <td>MWF - 7:00- 9:00</td>
				    <td>Dr. Melvin M. Niñal</td>
				  </tr>
				    <tr>
				    <td>Capstone 41</td>
				    <td>MWF - 7:30- 8:30</td>
				    <td>Ms. Catherine Carumba</td>
				  </tr>
				</table>
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
@stop
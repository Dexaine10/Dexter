@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>Education Background</h3>

              <div class="panel panel-default">
                <center>
          				Elementary: Lahug Elementary School<BR><BR>
          				High School: Lahug Night High School<BR><BR>
                  College: Asian College of Technology <BR>
                  Course: Associate of Computer Technology <BR>
          				College: University Of Cebu (Main) <BR>
          				Course: Bachelor of Science in Information Technology
              </center>
              </div>
            </div>
        </div>
    </div>
</div>
@stop
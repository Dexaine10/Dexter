<?php $__env->startSection("content"); ?>
  <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h1>ABOUT PHP2 SUBJECT</h1>
              <div class="panel panel-default">
              	This is an advance version of the basic php subject.<BR><BR>
              	It integrates the use of frameworks to make the developer finish their work easily.<BR><BR>
              	The subject focuses more on the user interface and the features and techniques on how to make a better Website.<BR><BR>
              	The subject also integrates proper handling of queries.<BR><BR>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>